#!/data/data/com.termux/files/usr/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if [ ! -f index.html ]; then cd jingting || exit 1; fi
if ! command -v python >/dev/null 2>&1; then
  printf '请先运行：pkg install python -y\n'
  exit 1
fi
printf '请在手机浏览器打开：http://127.0.0.1:8080/\n'
python -m http.server 8080 --bind 127.0.0.1
